from django.contrib import admin
from django.urls import path, include
from .views import home  # import the new view

urlpatterns = [
    path('', home, name='home'),  # homepage
    path('tracker/', include('timetracker.urls')),  # existing time tracking
    path('admin/', admin.site.urls),
    # Add other apps like invoicing, reporting etc.
    path('', include('projects.urls')),

]
