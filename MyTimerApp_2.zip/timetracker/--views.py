from django.shortcuts import render, get_object_or_404, redirect
from django.utils.timezone import now
from django.http import JsonResponse
from .models import TimeEntry
from .forms import ManualEntryForm
from projects.models import Project, Task


def tracker_home(request):
    running_entry = TimeEntry.objects.filter(end_time__isnull=True).first()
    past_entries = TimeEntry.objects.filter(end_time__isnull=False).order_by('-start_time')[:10]
    form = ManualEntryForm()
    return render(request, 'timetracker/tracker.html', {
        'running_entry': running_entry,
        'past_entries': past_entries,
        'form': form,
        'projects': Project.objects.all(),
        'tasks': Task.objects.all(),
    })
def start_timer(request):
    if request.method == "POST":
        project_id = request.POST.get("project")
        task_id = request.POST.get("task")
        description = request.POST.get("description")
        TimeEntry.objects.create(
            project_id=project_id,
            task_id=task_id,
            description=description,
            start_time=now()
        )
    return redirect('tracker_home')

def stop_timer(request, entry_id):
    entry = get_object_or_404(TimeEntry, pk=entry_id)
    entry.end_time = now()
    entry.save()
    return redirect('tracker_home')

def continue_entry(request, entry_id):
    entry = get_object_or_404(TimeEntry, pk=entry_id)
    TimeEntry.objects.create(
        project=entry.project,
        task=entry.task,
        description=entry.description,
        start_time=now()
    )
    return redirect('tracker_home')

def duplicate_entry(request, entry_id):
    entry = get_object_or_404(TimeEntry, pk=entry_id)
    TimeEntry.objects.create(
        project=entry.project,
        task=entry.task,
        description=entry.description,
        start_time=entry.start_time,
        end_time=entry.end_time
    )
    return redirect('tracker_home')

def submit_manual_entry(request):
    if request.method == "POST":
        form = ManualEntryForm(request.POST)
        if form.is_valid():
            form.save()
    return redirect('tracker_home')