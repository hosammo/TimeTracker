from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from django.utils.timezone import now
from django.views.decorators.csrf import csrf_exempt
from timetracker.forms import ManualEntryForm
from django.db.models import Sum
from datetime import timedelta
from django.shortcuts import redirect
from django.utils.timezone import now
from projects.models import Project, Task
from django.utils.timezone import now
from django.shortcuts import get_object_or_404, redirect
from timetracker.models import TimeEntry

def tracker_home(request):
    running_entry = TimeEntry.objects.filter(end_time__isnull=True).first()
    past_entries = TimeEntry.objects.filter(end_time__isnull=False).order_by('-start_time')

    form = ManualEntryForm()
    projects = Project.objects.all()
    tasks = Task.objects.all()

    progress_percent = 0
    if running_entry:
        duration = (now() - running_entry.start_time).total_seconds() / 3600  # hours
        progress_percent = min(100, int((duration / 8) * 100))

    return render(request, "timetracker/tracker.html", {
        "running_entry": running_entry,
        "past_entries": past_entries,
        "form": form,
        "projects": projects,
        "tasks": tasks,
        "progress_percent": progress_percent,
    })

def tasks_by_project(request):
    project_id = request.GET.get("project")
    tasks = Task.objects.filter(project_id=project_id)
    return render(request, "timetracker/partials/task_options.html", {"tasks": tasks})

@csrf_exempt
def ajax_add_project(request):
    if request.method == "POST":
        name = request.POST.get("name")
        if name:
            Project.objects.create(name=name, client=Project.objects.first().client)
    return render(request, "timetracker/partials/project_options.html", {"projects": Project.objects.all()})

@csrf_exempt
def ajax_add_task(request):
    if request.method == "POST":
        name = request.POST.get("name")
        project_id = request.POST.get("project_id")
        if name and project_id:
            Task.objects.create(name=name, project_id=project_id)
    return render(request, "timetracker/partials/task_options.html", {"tasks": Task.objects.filter(project_id=project_id)})

def start_timer(request):
    if request.method == "POST":
        project_id = request.POST.get("project")
        task_id = request.POST.get("task")
        description = request.POST.get("description")

        TimeEntry.objects.create(
            project_id=project_id,
            task_id=task_id if task_id else None,
            description=description,
            start_time=now()
        )
    return redirect('tracker_home')

def stop_timer(request, entry_id):
    entry = get_object_or_404(TimeEntry, pk=entry_id, end_time__isnull=True)
    entry.end_time = now()
    entry.save()
    return redirect('tracker_home')

def continue_entry(request, entry_id):
    old_entry = get_object_or_404(TimeEntry, pk=entry_id)
    TimeEntry.objects.create(
        project=old_entry.project,
        task=old_entry.task,
        description=old_entry.description,
        start_time=now()
    )
    return redirect('tracker_home')

def duplicate_entry(request, entry_id):
    entry = get_object_or_404(TimeEntry, pk=entry_id)
    TimeEntry.objects.create(
        project=entry.project,
        task=entry.task,
        description=entry.description,
        start_time=entry.start_time,
        end_time=entry.end_time
    )
    return redirect('tracker_home')

def submit_manual_entry(request):
    if request.method == "POST":
        form = ManualEntryForm(request.POST)
        if form.is_valid():
            form.save()
    return redirect('tracker_home')

